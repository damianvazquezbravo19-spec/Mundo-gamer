document.getElementById("contactForm").addEventListener("submit", (e) => {
  e.preventDefault();
  alert("¡Gracias por contactarte con Mundo Gamer!");
});